export const environment = {
  production: true,
  firebase:{
    // apiKey: "AIzaSyAEM8Eq61mSg3Bf4Zol4-RTTGTFHfvMBro",
    // authDomain: "oshop-642e3.firebaseapp.com",
    // projectId: "oshop-642e3",
    // storageBucket: "oshop-642e3.appspot.com",
    // messagingSenderId: "357899471186",
    // appId: "1:357899471186:web:568595716ea8c55066528b",
    // measurementId: "G-W081Z2PXVQ"
    apiKey: "AIzaSyAEM8Eq61mSg3Bf4Zol4-RTTGTFHfvMBro",
    authDomain: "oshop-642e3.firebaseapp.com",
    databaseURL: "https://oshop-642e3-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "oshop-642e3",
    storageBucket: "oshop-642e3.appspot.com",
    messagingSenderId: "357899471186",
    appId: "1:357899471186:web:568595716ea8c55066528b",
    measurementId: "G-W081Z2PXVQ"
  }
};
